<?php
// No permitir acceso directo
defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

$phoneNumber = $params->get('phone_number', '');

require JModuleHelper::getLayoutPath('mod_whatsapp_button');
?>
