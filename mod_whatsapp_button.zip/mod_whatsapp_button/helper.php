<?php
// No permitir acceso directo
defined('_JEXEC') or die;

class ModWhatsappButtonHelper {
    // Puedes agregar métodos útiles aquí si es necesario
}
?>
