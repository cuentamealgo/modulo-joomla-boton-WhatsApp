<?php
// Evita el acceso directo
defined('_JEXEC') or die;

// Incluye los archivos CSS
$document = JFactory::getDocument();
$document->addStyleSheet(JUri::base() . 'modules/mod_whatsapp_button/style.css');

// Aquí es donde se coloca el código HTML del botón de WhatsApp
?>
<div class="whatsapp-button">
    <a href="https://api.whatsapp.com/send?phone=<?php echo htmlspecialchars($params->get('phone_number')); ?>&amp;text=Hola, ¿en qué podemos ayudarte?" target="_blank">
        <img src="<?php echo JUri::base(); ?>modules/mod_whatsapp_button/images/iconowasacuadrado.webp" alt="WhatsApp" class="whatsapp-icon">
        ¡Déjanos un whatsapp!
    </a>
</div>

